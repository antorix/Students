from time import strftime, localtime
from datetime import datetime

print(strftime("%d %b %Y %H:%M:%S", localtime())) 

print("123" + strftime("%b", localtime())) 

print(strftime("%Y-%m-%d", localtime()))

print(int(strftime("%Y", localtime()))-2000)

print('{:%Y-%m-%d %H:%M}'.format(datetime(2001, 2, 3, 4, 5)))

print("***")

curDate = int( str(int(strftime("%Y", localtime()))-2000) + strftime("%m%d", localtime()) )
print("curDate is %d " % curDate)

input()
