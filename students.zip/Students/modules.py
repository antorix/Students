#!/usr/bin/python
# -*- coding: utf-8 -*-

from os import rename, remove, path, makedirs
from time import strftime, localtime

def is_ascii(s):
    return all(ord(c) < 128 for c in s)

def load():
    # If students.txt is present, reading from it, else returning void list    
    student = []    
    if path.exists("students.txt") == 0: return student
    else:       
        try:        
            with open("students.txt", "r", encoding="utf-8") as f: allstudents = [line.rstrip() for line in f]        
        except:
            with open("students.txt", "r") as f: allstudents = [line.rstrip() for line in f]         

        student.append([allstudents[0], allstudents[1], allstudents[2], allstudents[3], allstudents[4], allstudents[5], allstudents[6],
                                        [ # creating a new date list (invisible) in sortable format
                                                allstudents[1][6], allstudents[1][7], allstudents[1][3], allstudents[1][4], allstudents[1][0], allstudents[1][1]
                                        ],
                                        [
                                                allstudents[2][6], allstudents[2][7], allstudents[2][3], allstudents[2][4], allstudents[2][0], allstudents[2][1]
                                        ]
                                ])
        b = 7
        for a in range(int(len(allstudents)/7)-1):
            student.append([allstudents[b], allstudents[b+1], allstudents[b+2], allstudents[b+3], allstudents[b+4], allstudents[b+5], allstudents[b+6],
                                                        [ # creating a new date list (invisible) in sortable format
                                                                allstudents[b+1][6], allstudents[b+1][7], allstudents[b+1][3], allstudents[b+1][4], allstudents[b+1][0], allstudents[b+1][1]
                                                        ], 
                                                        [
                                                                allstudents[b+2][6], allstudents[b+2][7], allstudents[b+2][3], allstudents[b+2][4], allstudents[b+2][0], allstudents[b+2][1]
                                                        ]
                                                ])
            b += 7
    for i in range(len(student)): # creating additional temporary integer field for sorting by counsel
            if(student[i][3]) != "":
                try: student[i].append(int(student[i][3]))
                except: pass
            else:
                student[i].append(0)
    return student

def save(student, limit):
    # Saving and backing up student list

    if not path.exists("./backup"):
        makedirs("./backup")
    
    for i in range(1, 99): # counting existing backup files
        file_i = "./backup/students_" + ("%03d" % i) + ".txt"
        if path.isfile(file_i):
            backupnumber = limit
            continue
        else:
            backupnumber = i-1
            break
    
    if i < limit+1: # limit not reached, regular backup
        newbkfile = open(file_i, "w", encoding="utf-8")
        for a in range(len(student)):
            for i in range(7):
                newbkfile.write(str(student[a][i]) + "\n")
        newbkfile.close()
        
    else: # limit reached, first renaming up to the limit
        remove("./backup/students_001.txt")
        for i in range(1, backupnumber):
            if i <= limit:
                file_i = "./backup/students_" + ("%03d" %  i)    + ".txt"
                file_i1= "./backup/students_" + ("%03d" % (i+1)) + ".txt"
                rename(file_i1, file_i)            
    
        with open(file_i1, "w", encoding="utf-8") as newbkfile:
            for a in range(len(student)):
                for i in range(7):
                    newbkfile.write(str(student[a][i]) + "\n")

        for i in range(limit, 999): # deleting all files after limit, if any
            file_i= "./backup/students_" + ("%03d" % i) + ".txt"
            if path.isfile(file_i):
                remove(file_i)

    # Saving students
    
    with open("students.txt", "w", encoding="utf-8") as newfile:
        for a in range(len(student)):
            for i in range(7):
                newfile.write(str(student[a][i]) + "\n")        

def date(lang):
    # Returns XX.XX.XX formatted date in either English (lang==0) or Russian (lang==1) type

    if strftime("%b", localtime()) == "Jan": month = "01"
    elif strftime("%b", localtime()) == "Feb": month = "02"
    elif strftime("%b", localtime()) == "Mar": month = "03"
    elif strftime("%b", localtime()) == "Apr": month = "04"
    elif strftime("%b", localtime()) == "May": month = "05"
    elif strftime("%b", localtime()) == "Jun": month = "06"
    elif strftime("%b", localtime()) == "Jul": month = "07"
    elif strftime("%b", localtime()) == "Aug": month = "08"
    elif strftime("%b", localtime()) == "Sep": month = "09"
    elif strftime("%b", localtime()) == "Oct": month = "10"
    elif strftime("%b", localtime()) == "Nov": month = "11"
    elif strftime("%b", localtime()) == "Dec": month = "12"
    
    if lang == 1:
        return strftime("%d.", localtime()) + month + "." + str( int( strftime("%Y", localtime()) )-2000 )
            
    if lang == 0:
        return month + "/" + strftime("%d/", localtime()) + str( int( strftime("%Y", localtime()) )-2000 )
